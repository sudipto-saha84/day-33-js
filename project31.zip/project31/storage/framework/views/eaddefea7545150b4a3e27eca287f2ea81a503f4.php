<h1 id="headingTag" class="text-center">Hello World</h1>


    <div class="py-5">
        <ul class="nav">
            <li class="nav-item ">
                <a href="" id="colorRed" class="btn btn-danger nav-link float-left">Red</a></li>
            <li class="nav-item "> <a href="" id="colorGreen" class="btn btn-success nav-link float-left">Green</a></li>
            <li class="nav-item "> <a href="" id="colorGray" class="btn btn-primary nav-link float-left">Gray</a></li>
            <li class="nav-item "> <a href="" id="colorBlack" class="btn btn-secondary nav-link float-left">Black</a>
            </li>
        </ul>
    </div>

    <div id="box" class="mt-3" style="height: 300px; width: 300px; border: 1px solid orange" >

    </div>
<script>
    var colorGreen = document.getElementById('colorGreen')
    var box = document.getElementById('box')
    colorGreen.onclick=function () {
        event.preventDefault()

        box.style.backgroundColor = 'green';
    }

    var colorRed = document.getElementById('colorRed')
    colorRed.onclick = function () {

        event.preventDefault()
        box.style.backgroundColor = 'red';
    }
    var colorGray =document.getElementById('colorGray')
    colorGray.onclick = function () {

        event.preventDefault()
        box.style.backgroundColor = 'gray';
    }
    var colorBlack =document.getElementById('colorBlack')
    colorBlack.onclick = function () {

        event.preventDefault()
        box.style.backgroundColor = 'black';
    }


    var heading =document.getElementById('headingTag');
    heading.onclick=function () {
        heading.innerText = 'Hello Bitm';
        heading.style.color ='green';
    }

    heading.onselect =function () {

        heading.innerText = 'Hi';
    }
    heading.onmouseover =function () {

        heading.style.color = 'red';
    }
    heading.onmouseleave = function () {

        heading.style.color = 'black';
    }
</script>
<?php /**PATH C:\xampp\htdocs\project31\resources\views/includes/color-change.blade.php ENDPATH**/ ?>