<?php $__env->startSection('title'); ?>
    Java Script
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>




    <?php echo $__env->make('includes.image-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.color-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <h1 id="h1"></h1>


    <div id="content">

    </div>

    <script>
        var name = 'jennifer';
        document.write(name) ;
        var data = [10,20,30];
       for (key in data)
       {
           document.write(data[key]+'<br>');
       }

        var student= {name:'Santo', phone:'01325452200',email:'snapok.sekjh@gsajkns.com'};
        var jennifer= {name:'jennifer', phone:'01999945444',email:'jeenifer.sekjh@gsajkns.com'};
       // document.write(students.email);

        var students = [
            {name:'Santo', phone:'01325452200',email:'snapok.sekjh@gsajkns.com'},
            {name:'Arif', phone:'012009999984',email:'arif.sekjh@gsajkns.com'},
            {name:'Sudipto', phone:'0877454545',email:'sudipto.sekjh@gsajkns.com'},
            {name:'jennifer', phone:'999988855',email:'jennifer.sekjh@gsajkns.com'},
            {name:'Sawon', phone:'8885221422',email:'sawon.sekjh@gsajkns.com'},
            {name:'Sajjad', phone:'9898852121',email:'sajjad.sekjh@gsajkns.com'},
        ];


        // document.write(students.email);

        for (index in students)
        {
            document.write('Student Name :'+students[index].name +'  Student Phone :'+students[index].phone+' Student Email:'+students[index].email +'<br>');
        }


    </script>



    <script>

        function createDiv(height,width,color) {
            var div = document.createElement('div');
            div.style.height=height+'px';
            div.style.width =width+'px';
            div.style.backgroundColor =color+'';
            div.style.float='left';

            // div.style.borderRadius= '250px';
            div.setAttribute('id','colorDiv');


            var content =document.getElementById('content');
            content.append(div);
        }
        // createDiv(300,400,'red');
        // createDiv(200,100,'green');
        // createDiv(300,150,'gray');
        // createDiv(300,500,'black');




        // var firstName = 'Sawon';
        // var lastName = 'Akter';

        // function printName() {
        //
        //
        //
        //     // document.write(firstName + ' '+ lastName);
        // }
        // printName();


        // getResult(101,2);
        //
        // function getResult(firstNumber, lastNumber) {
        //
        //     document.write(firstNumber-lastNumber+'<br>');


        // }
        // getResult(100,49);
        // getResult(500,49);
        // getResult(600,49);
        //

        function getFullName(firstName,lastName) {

            var fullName = firstName+' '+lastName;
            var h1 =document.getElementById('h1');
            // var h1 =document.getElementsByTagName('h1');
           document.getElementsByTagName('h1')[0] .innerHTML = fullName;
        }
        // getFullName("HAbibur","rahman");


        // function name() {
        //
        //     document.write('Tarek');
        //     alert('hello world');
        //
        // }
        // name();





        /*

        ****function****
        * a block of code
        * can not work alone
        * work by calling
        * used for specific work
        * re useable
        *
        *
        * 2 part of a function
        * 1. defination
        * 2.call

         */



        // var data = ['shila','saadia',100,200.25,'bitm','bangladesh',655];




        // for(index in data)
        // {
        //     if (index > 1)
        //     {
        //         document.write(data[index]+ '<br>');
        //     }
        //

            // document.write(data[index]+'<br>');

            // document.write(index + '<br>');
        // }


        // document.write(data[6]);











//        var firstName = 'Sanjida';
//        var lastName ='Akter';
//
//        document.write(firstName+ '&nbsp &nbsp &nbsp ' + lastName);



        // document.write("hello world");

        // major rules for variable
        //     *start with var
        // *a-z,A_Z,,0-9, $
        // *no number in first

        // var name = 'sudipto';
        // var street  = '22 street';
        // var Bangladesh = 'Hello Bangladesh';
        // var arif_name = 'his name is arif';
        // var hellojennifer = 'Hello  Jennifer';
        //
        //
        // document.write(typeof('hello world'));




    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project31\resources\views/js/js.blade.php ENDPATH**/ ?>