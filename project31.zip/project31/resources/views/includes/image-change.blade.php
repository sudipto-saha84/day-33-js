<style>
    .small-image{
        height: 100px;
        width: 100px;
        cursor: pointer;
    }
</style>

<div class="ml-5" style="height: 400px; width: 600px!important;" >
    <img src="{{asset('assets/img/1.jpg')}}" alt="" class="img-fluid w-100 h-100" id="image"/>
</div>
<div class="ml-5 mt-2">
    <img src="{{asset('assets/img/1.jpg')}}" alt="" class="small-image" id="smallImage1"/>
    <img src="{{asset('assets/img/2.jpg')}}" alt="" class="small-image" id="smallImage2"/>
    <img src="{{asset('assets/img/3.jpg')}}" alt="" class="small-image" id="smallImage3"/>
    <img src="{{asset('assets/img/4.jpg')}}" alt="" class="small-image" id="smallImage4"/>
</div>

<script>
    var image =document .getElementById('image');
    var image1 = document.getElementById('smallImage1')
    var image2 = document.getElementById('smallImage2')
    var image3 = document.getElementById('smallImage3')
    var image4= document.getElementById('smallImage4')


    image1.onclick=function () {

        image.setAttribute("src","{{asset('assets/img/1.jpg')}}")
    }
    image2.onclick=function () {

        image.setAttribute("src","{{asset('assets/img/2.jpg')}}")
    }
    image3.onclick=function () {

        image.setAttribute("src","{{asset('assets/img/3.jpg')}}")
    }
    image4.onclick= function () {

        image.setAttribute("src","{{asset('assets/img/4.jpg')}}")
    }

</script>

