

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center">Product Upload form</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="">

                            <div class="form-group row">
                                <label for="1" class="col-md-3 col-form-label">Product Name</label>
                                <div class="col-md-9">
                                    <input type="text" id="1" class="form-control" name="name">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="2" class="col-md-3 col-form-label">Product Price</label>
                                <div class="col-md-9">
                                    <input type="text" id="2" class="form-control" name="price">
                                </div>
                            </div>
                            -*-*/
                            <div class="form-group row">
                                <label for="2" class="col-md-3 col-form-label">Product Price</label>
                                <div class="col-md-9">
                                    <input type="text" id="2" class="form-control" name="price">
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
